<?php

namespace App\Http\Controllers\MasterRolePermission;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AssignModuleRoleContoller extends Controller
{
    //
}
