<section class="wide-tb-100 bg-scroll bg-img-6 pos-rel callout-style-1">
    <div class="bg-overlay blue opacity-80"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <h1 class="heading-main light-mode">
                    <small>Help Other People</small>
                    We Dream to Create A Bright Future Of The Underprivileged Children
                </h1>
            </div>
            <div class="col-sm-12 text-md-end">
                <a href="{{route('donation')}}" class="btn btn-default">Donate Now</a>
            </div>
        </div>
    </div>
</section>
