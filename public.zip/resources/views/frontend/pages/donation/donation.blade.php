@extends('frontend.layouts.siteLayout')
@section('pageTitle')
    Paulsabinna Foundation - Donation
@endsection
@section('setHomeActive')
    active
@endsection


@section('content')
    <section class="breadcrumbs-page-wrap">
        <div class="bg-fixed pos-rel breadcrumbs-page">
            <div class="container">
                <h1>Donation</h1>
                <nav aria-label="breadcrumb" class="breadcrumb-wrap">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('/') }}">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Donation</li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>


    <section class="wide-tb-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <h1 class="heading-main">
                        <small>Donation</small>
                        Don't Let Poverty Destroy Someone's Dreams
                    </h1>
                    <p>The secret to happiness lies in helping others. Never underestimate the difference YOU
                        can make in the lives of the poor, the abused and the helpless. Spread sunshine in their
                        lives no matter what the weather may be.</p>
                    <div class="donation-wrap">

                        <div class="row mt-5">
                            <div class="col-sm-6 col-md-6 col-lg-4">

                                <div class="card" style="">
                                    <div class="card-header">
                                        BANK PAYMENT
                                    </div>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">ACCOUNT NAME: PAULSABINNA FOUNDATION FOR THE
                                            NEEDY</li>
                                        <li class="list-group-item">ACCOUNT NUMBER: 1026603899</li>
                                        <li class="list-group-item">CURRENCY: NGN</li>
                                        <li class="list-group-item">BANK NAME: UNITED BANK FOR AFRICA.</li>
                                        <li class="list-group-item"> BANK ADDRESS: 74 IKOTUN IDIMU ROAD IKOTUN LAGOS
                                            NIGERIA.</li>
                                    </ul>
                                </div>

                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-4">

                                <div class="card" style="">
                                    <div class="card-header">
                                        BANK PAYMENT
                                    </div>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">ACCOUNT NAME: PAULSABINNA FOUNDATION FOR THE NEEDY</li>
                                        <li class="list-group-item">ACCOUNT NUMBER: 3004226269</li>
                                        <li class="list-group-item">CURRENCY: USD</li>
                                        <li class="list-group-item">SORT CODE: 033153322 </li>
                                        <li class="list-group-item">SWIFT CODE: UNAFNGLA</li>
                                        <li class="list-group-item">BANK NAME: UNITED BANK FOR AFRICA.</li>
                                        <li class="list-group-item"> BANK ADDRESS: 74 IKOTUN IDIMU ROAD IKOTUN LAGOS
                                            NIGERIA.</li>
                                    </ul>
                                </div>

                            </div>

                            <div class="w-100 d-none d-sm-none d-md-block d-lg-none spacer-30"></div>

                            <div class="col-sm-6 col-md-6 col-lg-4">

                                <div class="card" style="">
                                    <div class="card-header">
                                        BANK PAYMENT
                                    </div>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">ACCOUNT NAME: PAULSABINNA FOUNDATION FOR THE NEEDY</li>
                                        <li class="list-group-item">ACCOUNT NUMBER: 3004226276</li>
                                        <li class="list-group-item">CURRENCY: EUR</li>
                                        <li class="list-group-item">SORT CODE: 033153322 </li>
                                        <li class="list-group-item">SWIFT CODE: UNAFNGLA</li>
                                        <li class="list-group-item">BANK NAME: UNITED BANK FOR AFRICA.</li>
                                        <li class="list-group-item"> BANK ADDRESS: 74 IKOTUN IDIMU ROAD IKOTUN LAGOS
                                            NIGERIA.</li>
                                    </ul>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="faqs-sidebar pos-rel">
                        <div class="bg-overlay blue opacity-80"></div>
                        <form>
                            <h3 class="h3-sm fw-7 txt-white mb-3">Have any Question?</h3>
                            <div class="form-group">
                                <label for="fullname"><strong>Full Name</strong></label>
                                <input type="text" class="form-control form-light" id="fullname">
                            </div>
                            <div class="form-group">
                                <label for="emailform"><strong>Email Address</strong></label>
                                <input type="email" class="form-control form-light" id="emailform">
                            </div>
                            <div class="form-group">
                                <label for="questionmsg"><strong>How can help you?</strong></label>
                                <textarea class="form-control form-light" rows="5" id="questionmsg"></textarea>
                            </div>
                            <button type="submit" class="btn btn-default mt-3">Ask It Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="wide-tb-150 bg-scroll bg-img-6 pos-rel callout-style-1">
        <div class="bg-overlay blue opacity-80"></div>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7">
                    <h1 class="heading-main light-mode">
                        <small>Help Other People</small>
                        We Dream to Create A Bright Future Of The Underprivileged Children
                    </h1>
                </div>
                <div class="col-sm-12 text-md-end">
                    <a href="donation-page.html" class="btn btn-default">Donate Now</a>
                </div>
            </div>
        </div>
    </section>


    @include('frontend.pages.common.partner')
@endsection


@section('styles')
@endsection


@section('scripts')
@endsection
