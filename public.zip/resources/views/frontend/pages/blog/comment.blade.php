<img class="thumb" src="{{ asset('frontend/assets/images/sidebar_thumb_2.jpg') }}" alt>
<div class="media-body">
    <div class="d-flex justify-content-between mb-3">
        <div class>
            <h4 class="mb-0 txt-orange">Karon Balina</h4>
            <small class="txt-blue">17, Aug, 2020</small>
        </div>
        <div>
            <a href="#" class="read-more-line"><span>Reply</span></a>
        </div>
    </div>
    <p>{{ $comment->comment }}</p>
    <div class="media reply-box">
        <img src="{{ asset('frontend/assets/images/sidebar_thumb_3.jpg') }}" alt class="thumb ">
        <div class="media-body">
            <div class="d-flex justify-content-between mb-3">
                <div class>
                    <h4 class="mb-0 txt-orange">Karon Balina</h4>
                    <small class="txt-blue">17, Aug, 2020</small>
                </div>
                <div>
                    <a href="#" class="read-more-line"><span>Reply</span></a>
                </div>
            </div>
            Cras sit amet nibh libero, in gravida nulla. Nulla vel metus
            scelerisque ante sollicitudin. Cras
            purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce
            condimentum nunc ac nisi
            vulputate fringilla. Donec lacinia congue felis in faucibus.
        </div>
    </div>
</div>
