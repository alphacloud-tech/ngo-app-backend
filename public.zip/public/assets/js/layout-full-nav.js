(function($) {
    "use strict"

    new quixSettings({
        sidebarStyle: "full", 
    });


})(jQuery);