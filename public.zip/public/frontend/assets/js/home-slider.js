// (function ($) {
//     "use strict";

//     $(".main-banner .owl-carousel").on("initialized.owl.carousel", () => {
//         setTimeout(() => {
//             $(".owl-item.active .owl-slide-animated").addClass("is-transitioned");
//             $("section").show();
//         }, 200);
//     });

//     const $owlCarousel = $(".main-banner .owl-carousel").owlCarousel({
//         items: 1,
//         loop: true,
//         autoplay: true,
//         autoplayHoverPause: true,
//         mouseDrag: false,
//         autoHeight: true,
//         nav: true,
//         dots: false,
//         navText: [
//             '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
//             '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>']
//     });



//     $owlCarousel.on("changed.owl.carousel", e => {
//         $(".owl-slide-animated").removeClass("is-transitioned");

//         const $currentOwlItem = $(".owl-item").eq(e.item.index);
//         $currentOwlItem.find(".owl-slide-animated").addClass("is-transitioned");

//         const $target = $currentOwlItem.find(".owl-slide-text");
//         doDotsCalculations($target);
//     });

//     $owlCarousel.on("resize.owl.carousel", () => {
//         setTimeout(() => {
//             setOwlDotsPosition();
//         }, 50);
//     });

//     /*if there isn't content underneath the carousel*/
//     //$owlCarousel.trigger("refresh.owl.carousel");

//     setOwlDotsPosition();

//     function setOwlDotsPosition() {
//         const $target = $(".owl-item.active .owl-slide-text");
//         doDotsCalculations($target);
//     }

//     function doDotsCalculations(el) {
//         const height = el.height();
//         const { top, left } = el.position();
//         const res = height + top + 20;

//         $(".main-banner .owl-carousel .owl-dots").css({
//             top: `${res}px`,
//             left: `${left}px`
//         });

//     }

// }(jQuery));



(function ($) {
    "use strict";

    $(".main-banner .owl-carousel").on("initialized.owl.carousel", () => {
        setTimeout(() => {
            $(".owl-item.active .owl-slide-animated").addClass("is-transitioned");
            $("section").show();
        }, 200);
    });

    const $owlCarousel = $(".main-banner .owl-carousel").owlCarousel({
        items: 1,
        loop: true,
        autoplay: true,
        autoplayHoverPause: true,
        mouseDrag: false,
        autoHeight: true,
        nav: true,
        dots: false,
        navText: [
            '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
            '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>'
        ]
    });

    $owlCarousel.on("changed.owl.carousel", e => {
        $(".owl-slide-animated").removeClass("is-transitioned");

        const $currentOwlItem = $(".owl-item").eq(e.item.index);
        $currentOwlItem.find(".owl-slide-animated").addClass("is-transitioned");

        const $target = $currentOwlItem.find(".owl-slide-text");
        doDotsCalculations($target);
    });

    $owlCarousel.on("resize.owl.carousel", () => {
        setTimeout(() => {
            setOwlDotsPosition();
        }, 50);
    });

    /*if there isn't content underneath the carousel*/
    //$owlCarousel.trigger("refresh.owl.carousel");

    setOwlDotsPosition();

    function setOwlDotsPosition() {
        const $target = $(".owl-item.active .owl-slide-text");
        doDotsCalculations($target);
    }

    // function doDotsCalculations(el) {
    //     const height = el.height();
    //     const { top, left } = el.position();
    //     const res = height + top + 20;

    //     $(".main-banner .owl-carousel .owl-dots").css({
    //         top: `${res}px`,
    //         left: `${left}px`
    //     });

    // }

    function doDotsCalculations(el) {
        if (el instanceof jQuery) {
            const height = el.height();
            const position = el.position();

            if (position) {
                const { top, left } = position;
                const res = height + top + 20;

                $(".main-banner .owl-carousel .owl-dots").css({
                    top: `${res}px`,
                    left: `${left}px`
                });
            }
        }
    }

}(jQuery));

